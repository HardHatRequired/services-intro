'use strict';


var myApp = angular.module('artistApp', []);
